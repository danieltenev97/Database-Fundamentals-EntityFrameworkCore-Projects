﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftJail.DataProcessor.ImportDto
{
    public class CellsDto
    {
        public int CellNumber { get; set; }
        public bool hasWindow { get; set; }
    }
}
