﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data.Models
{
  public class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-FN9KGGA\SQLEXPRESS;Database=Hospital;Integrated Security=True";

    }
}
